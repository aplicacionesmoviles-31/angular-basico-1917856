package com.democapacitor.fcfm;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}