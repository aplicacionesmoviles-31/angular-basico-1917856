import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-publicacion',
  templateUrl: './publicacion.component.html',
  styleUrls: ['./publicacion.component.css']
})
export class PublicacionComponent implements OnInit {

  constructor(private ruta: ActivatedRoute) { }

  ngOnInit(): void {
    this.buscarPublicacion();
  }

  publicacion = this.ruta.snapshot.params['id'];

  publicaciones =[{
    "usuario" : "@kfc",
    "imagen" : "https://pbs.twimg.com/profile_images/1506919200618684424/fMqxAhgy_400x400.jpg",
    "caption" : "Excelente",
    "comentario" : "",
    "id" : "asd468adasd6fg"
    
},
{
  "usuario" : "@Anon",
  "imagen" : "https://http2.mlstatic.com/D_NQ_NP_757001-MLM43956898609_102020-O.jpg",
  "caption" : "Excelente libro!",
  "comentario" : "",
  "id" : "doijgrowirv8468syg"
  
},
{
  "usuario" : "@Rex",
  "imagen" : "https://www.elsolucionario.org/wp-content/archivos/2013/04/fundamentos-de-sistemas-operativos-abraham-silberschatz-peter-baer-galvin-7ma-edicion.jpg",
  "caption" : "Dinosaurios",
  "comentario" : "",
  "id" : "llaslvmnivvur8496551uhjhcka2+56"
}] ;

  publicacionDetalle: any={}

  buscarPublicacion(): any {
    for(let i = 0; i < this.publicaciones.length; i++) {
      if(this.publicaciones[i].id == this.publicacion) {
        this.publicacionDetalle = this.publicaciones[i];
      }
    }
    return this.publicacionDetalle;
  }
  
  
}