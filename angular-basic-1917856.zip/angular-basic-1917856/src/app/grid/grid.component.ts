import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';

import{Firestore, collectionData, collection} from '@angular/fire/firestore';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})
export class GridComponent implements OnInit {

  publicaciones: any = {};
  resPublicaciones: any = [];

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.getPublicaciones().subscribe(res =>{
      this.resPublicaciones = res;
      console.log(this.resPublicaciones);
    });
  }
  
  getPublicaciones(){ 
    return this.http.get('https://insta-ionic-7c946-default-rtdb.firebaseio.com/publicaciones.json')
    
  }
  

}