import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-galeria',
  templateUrl: './galeria.component.html',
  styleUrls: ['./galeria.component.css']
})
export class GaleriaComponent implements OnInit {

  constructor(private http: HttpClient) { }

  publicaciones: any = {};
  resPublicaciones: any = [];
  
  ngOnInit(): void {
    this.getPublicaciones().subscribe(res =>{
      this.resPublicaciones = res;
      console.log(this.resPublicaciones);
    });
    
  }

  galeria = true;

  mostrarGaleria(mostrarSiNo:  boolean) {
    this.galeria = mostrarSiNo;
  }
  
  resArray = [];

  getPublicaciones(){ 
    return this.http.get('https://insta-ionic-7c946-default-rtdb.firebaseio.com/publicaciones.json')
    
  }
  
}