import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import * as data from 'src/datos.json'
import { dashCaseToCamelCase } from '@angular/compiler/src/util';
import { ActionSheetController } from '@ionic/angular';

@Component({
  selector: 'app-bio',
  templateUrl: './bio.component.html',
  styleUrls: ['./bio.component.css']
})
export class BioComponent implements OnInit {

  constructor(private actionSheetController: ActionSheetController) { }
  ngOnInit(): void {
    /*this.getUsuario().subscribe(res =>{
      this.resUsuario = res;
      console.log(this.resUsuario);
    });*/
  }
  siguiendo = false;
  editandoMensaje = false;
  editandoCorreo = false;


  
  usuario =
    {
      "alias": "@floppa",
      "bio": "Tu sabes quien soy",
      "fotoPerfil": "https://www.lifeder.com/wp-content/uploads/2022/04/floppa-foto.jpg",
      "nombre": "Floppa",
      "publicaciones": [
        "https://pbs.twimg.com/profile_images/1433764901005189121/Ot16nIoD_400x400.jpg",
        "https://upload.wikimedia.org/wikipedia/commons/7/75/Floppa.png",
        "https://pbs.twimg.com/profile_images/1429837249047191556/QQLX6GRr_400x400.jpg",
        "https://i.pinimg.com/736x/05/96/c0/0596c0050ccf804c8e775b36817aedf8.jpg"
      ],
      "seguidores": 1500,
      "seguidos": 6
    }
  
  resUsuario: any = [];

  async createActionSheet() {
    const actionSheet = await this.actionSheetController.create({
      buttons: [{
        text: 'Cancelar', 
        role: 'cancel'
      },
      {
        text: 'Bloquear usuario', 
        role: 'destructive'
      }]
    });

    await actionSheet.present();

    const { role, data } = await actionSheet.onDidDismiss();
    console.log('onDidDismiss resolved with role and data', role, data);
  }

  seguir(): void {
    this.siguiendo = !this.siguiendo;
  }

  enviarMensaje(): void {
    
  }

  enviarEmail(): void {

  }

  desplegarOpciones(): void {
    //En proceso.
  }
}