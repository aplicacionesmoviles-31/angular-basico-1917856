import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

//FIRE
import { AngularFireModule } from '@angular/fire/compat';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpClientModule } from '@angular/common/http';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { IonicModule } from '@ionic/angular';

import { TabsComponent } from './tabs/tabs.component';
import { FormsModule , ReactiveFormsModule} from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { RoutesModule } from './routes.module';
import { PublicarComponent } from './publicar/publicar.component';
import { Camera } from '@awesome-cordova-plugins/camera/ngx';

//Temporalmente
import { BioComponent } from './bio/bio.component';
import { GaleriaComponent } from './galeria/galeria.component';
import { CardsComponent } from './cards/cards.component';
import { GridComponent } from './grid/grid.component';
import { PublicacionComponent } from './publicacion/publicacion.component';
import { HistoriasComponent } from './historias/historias.component';

@NgModule({
  declarations: [
    AppComponent,
    CardsComponent,
    GridComponent,
    TabsComponent,
    GaleriaComponent,
    BioComponent,
    PublicacionComponent,
    HistoriasComponent, 
    PublicarComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    RoutesModule,
    HttpClientModule,
    AngularFireModule.initializeApp(environment.firebaseConfig),
    IonicModule.forRoot(), 
    ReactiveFormsModule
  ],
  providers: [
   Camera
  ],
  bootstrap: [AppComponent],
  exports: [RoutesModule]
})
export class AppModule { }