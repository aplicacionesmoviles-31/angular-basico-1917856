import { Component, OnInit, Input } from '@angular/core';
import {HttpClient} from '@angular/common/http';

//Firebase
import { FirebaseDbService } from '../firebase-db.service';
/*
import { AngularFireDatabase, AngularFireList } from '@angular/fire/compat/database';
import { Observable } from 'rxjs';
import{Firestore, collectionData, collection} from '@angular/fire/firestore';
import { map } from 'rxjs/operators';
*/
@Component({
  selector: 'app-cards',
  templateUrl: './cards.component.html',
  styleUrls: ['./cards.component.css']
})
export class CardsComponent implements OnInit {
  @Input() comentario: string = "";


  constructor(private http: HttpClient, 
    private dbFirebase: FirebaseDbService) { 

        //this.dataRef = this.dbF.list('publicaciones');
        //this.data = dataRef.valueChanges();

        //this.data = this.dbF.list('publicaciones').valueChanges();
  }
  
  //publicaciones: any = {};
  resPublicaciones: any = [];
  
  ngOnInit(): void {
    this.getPublicacionesRequest();
  }
  
  //data: Observable<any>;

  resArray = [];

  getPublicacionesRequest()  {
    this.dbFirebase.getPublicaciones().subscribe(res => {
      this.resPublicaciones = res;
    })
  }

  borrarPost(id: number) {
    this.dbFirebase.deletePublicacion(id.toString()).subscribe(res => {

      console.log(res);
      //console.log("deleted");
    })
  }
  ocultarPost(id: number) {
    //this.resPublicaciones 
  }

  postComment(comentario: string, publicacion: number): void {
    //publicacion.comentario = this.comentario;
    //this.comentario = "";

    //Aqui va el request de FirebaseDb
    this.comentario = "";
    this.comentario = comentario;
  }
}