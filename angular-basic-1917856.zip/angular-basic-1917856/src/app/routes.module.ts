import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { Routes, RouterModule } from '@angular/router';

import { CardsComponent  } from './cards/cards.component';
import { GridComponent } from './grid/grid.component';
import { PublicacionComponent } from './publicacion/publicacion.component';
import { PublicarComponent } from './publicar/publicar.component';


const routes: Routes  = [{
  /*{ path: 'cards', component: CardsComponent },
  { path: 'grid', component: GridComponent },
  { path: 'publicacion/:id', component: PublicacionComponent}*/
  path: 'cards',
    component: CardsComponent,
    loadChildren: () => import('./cards/cards.module').then(m => m.CardsModule)
  },
  {
    path: 'cards',
    component: CardsComponent,
    loadChildren: () => import('./cards/cards.module').then(m => m.CardsModule)
  },
  {
    path: 'grid',
    component: GridComponent,
    loadChildren: () => import('./grid/grid.module').then(m => m.GridModule)
  },
  {
    path: 'publicacion/:id',
    component: PublicacionComponent,
    loadChildren: () => import('./publicacion/publicacion.module').then(m => m.PublicacionModule)
  },
  {path: 'publicar', component: PublicarComponent},
  { path: '**', component: CardsComponent}
]


@NgModule({
  declarations: [],
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule]
})
export class RoutesModule { }