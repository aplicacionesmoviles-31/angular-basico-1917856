export interface Publicacion{
    caption: string,
    comentario : string,
    id: string,
    imagen: string,
    usuario: string
}