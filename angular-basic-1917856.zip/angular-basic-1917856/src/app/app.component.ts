import { Component, OnInit } from '@angular/core';
import { FirebaseDbService } from './firebase-db.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  /*title = 'angular-basico-1917856';
  grid = true;*/
  constructor(private fb: FirebaseDbService){}

  ngOnInit(): void {
    this.getUsuario().subscribe(res => {
      this.usuario = res.toString();
    })
    this.getFotoPerfil().subscribe(res => {
      this.fotoPerfil = res.toString();
    })
    
  }
  usuario : string = '';

  fotoPerfil: string = '';

  getUsuario() {
    return this.fb.getUsuario()
  }

  getFotoPerfil() {
    return this.fb.getFotoPerfil();
  }

  cerrarSesion() {
    //Work In Progress
  }

  /*numeros = [
    "1.- Floppa",
    "2.- Viaje a cancun",
    "3.- Resumenes",
    "4.- Ladrona de libros"
  ];
  
  toggleGrid(): void{
    this.grid = !this.grid;
  }*/
  }
