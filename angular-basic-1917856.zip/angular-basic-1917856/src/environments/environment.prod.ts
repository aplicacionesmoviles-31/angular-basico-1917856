export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyBl0trFZ5vwYrIPhzKJ_1CV8IXh1gD02mQ",
    authDomain: "appmoviles-f6170.firebaseapp.com",
    projectId: "appmoviles-f6170",
    storageBucket: "appmoviles-f6170.appspot.com",
    messagingSenderId: "584069168578",
    appId: "1:584069168578:web:66100a548d0add2dff6a5b"
  }
};