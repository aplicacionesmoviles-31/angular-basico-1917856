// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig:{
    apiKey: "AIzaSyBl0trFZ5vwYrIPhzKJ_1CV8IXh1gD02mQ",
   authDomain: "appmoviles-f6170.firebaseapp.com",
    projectId: "appmoviles-f6170",
   storageBucket: "appmoviles-f6170.appspot.com",
   messagingSenderId: "584069168578",
   appId: "1:584069168578:web:66100a548d0add2dff6a5b"

  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
