import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.capacitor1909553.fcfm',
  appName: 'app1909553v1',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;